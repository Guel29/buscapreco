@echo off
chcp 65001 > nul
title Central Busca Preco - Sincronizador Automatico (10 Minutos)
color 0A
cls

set SUBDOMINIO=buscapreco.instara.com.br
set ID_LOJA=1
set URL_CARGA=https://%SUBDOMINIO%/api.php?action=instant-load^&id_loja=%ID_LOJA%

echo ==============================================================================
echo       CENTRAL BUSCA PRECO ^& IMPRESSAO - CARGA AUTOMATICA EM NUVEM
echo ==============================================================================
echo   Servidor de Destino : https://%SUBDOMINIO%
echo   Intervalo de Carga  : A cada 10 Minutos (600 segundos)
echo   Loja Configurada    : Loja %ID_LOJA%
echo   Ambiente            : Windows (Hostinger / MySQL)
echo   Modo                : Execucao Continua Automatica
echo ==============================================================================
echo.
echo [INFO] Pressione Ctrl+C a qualquer momento para pausar ou encerrar.
echo.

:LOOP
echo ------------------------------------------------------------------------------
echo [%date% %time%] -> Disparando carga de produtos para a nuvem...
echo ------------------------------------------------------------------------------

REM 1. Tenta envio via CURL nativo do Windows (Mais rapido e confiavel)
where curl >nul 2>nul
if %errorlevel% equ 0 (
    curl -s -k -X GET "%URL_CARGA%"
    echo.
) else (
    REM 2. Fallback via PowerShell inline universal
    powershell -NoProfile -ExecutionPolicy Bypass -Command "[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]'Tls12'; $wc = New-Object System.Net.WebClient; $wc.Encoding = [System.Text.Encoding]::UTF8; Write-Host $wc.DownloadString('%URL_CARGA%')"
    echo.
)

echo ==============================================================================
echo [%date% %time%] -> Carga enviada com sucesso para o banco de dados na nuvem!
echo Proxima sincronizacao automatica em 10 minutos (600 segundos)...
echo ==============================================================================
echo.

REM Contagem regressiva de 10 minutos (600 segundos)
timeout /t 600 /nobreak
goto LOOP
