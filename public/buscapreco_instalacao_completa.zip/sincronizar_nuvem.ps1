# ==============================================================================
# SCRIPT DE CARGA E SINCRONIZAÇÃO EM NUVEM (POWERSHELL / WINDOWS)
# ==============================================================================
# Subdomínio: buscapreco.instara.com.br
# Compatível com: Todas as versões do PowerShell (Windows 7/8/10/11 / Server)
# ==============================================================================
param(
    [string]$Subdominio = "buscapreco.instara.com.br",
    [int]$IdLoja = 1
)

$ErrorActionPreference = "Continue"
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]'Tls,Tls11,Tls12'

$dataHora = Get-Date -Format "dd/MM/yyyy HH:mm:ss"
$urlCarga = "https://" + $Subdominio + "/api.php?action=instant-load" + [char]38 + "id_loja=" + $IdLoja

Write-Host "==============================================================================" -ForegroundColor DarkGray
Write-Host "  SINCRONIZADOR DE CARGA - BUSCA PRECO (NUVEM HOSTINGER)" -ForegroundColor Cyan
Write-Host "==============================================================================" -ForegroundColor DarkGray
Write-Host "  Servidor : https://$Subdominio" -ForegroundColor White
Write-Host "  Loja ID  : $IdLoja" -ForegroundColor White
Write-Host "  Horario  : $dataHora" -ForegroundColor White
Write-Host "------------------------------------------------------------------------------" -ForegroundColor DarkGray

try {
    Write-Host "[INFO] Enviando solicitacao de carga para a nuvem..." -ForegroundColor Yellow
    $webClient = New-Object System.Net.WebClient
    $webClient.Encoding = [System.Text.Encoding]::UTF8
    $json = $webClient.DownloadString($urlCarga)
    
    if ($json -match '"success"\s*:\s*true') {
        Write-Host "[$dataHora] [SUCESSO] Carga processada com exito na nuvem!" -ForegroundColor Green
        if ($json -match '"total_produtos"\s*:\s*([0-9]+)') {
            Write-Host "   Total de produtos ativos no MySQL: $($matches[1]) itens" -ForegroundColor Cyan
        }
    } else {
        Write-Host "[$dataHora] [AVISO] Resposta do servidor: $json" -ForegroundColor DarkYellow
    }
} catch {
    Write-Host "[$dataHora] [ERRO NA COMUNICACAO]: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Tentando disparo alternativo via cURL nativo..." -ForegroundColor DarkYellow
    try {
        & curl.exe -s -k -X GET $urlCarga
        Write-Host ""
    } catch {}
}

Write-Host "------------------------------------------------------------------------------" -ForegroundColor DarkGray
