<?php
/**
 * ==============================================================================
 * API REST MYSQL - CENTRAL DE CONSULTA DE PREÇOS HOSTINGER
 * ==============================================================================
 * Subdomínio: buscapreco.instara.com.br
 * ==============================================================================
 */

require_once __DIR__ . '/config.php';

// Tenta obter conexão sem interromper o script caso ainda esteja sendo configurado
$pdo = getDbConnection(null, true);

// Garante que as tabelas necessárias existam no MySQL automaticamente
function ensureTablesExist($pdo) {
    if (!$pdo) return;
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS lojas (
                id INT PRIMARY KEY AUTO_INCREMENT,
                nome VARCHAR(100) NOT NULL,
                subdominio VARCHAR(100) DEFAULT 'buscapreco.instara.com.br',
                criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS produtos (
                id VARCHAR(100) PRIMARY KEY,
                id_loja INT NOT NULL DEFAULT 1,
                codigo_interno VARCHAR(50) NOT NULL,
                codigo_barras VARCHAR(50) NOT NULL,
                descricao VARCHAR(255) NOT NULL,
                preco DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                preco_venda DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                embalagem VARCHAR(20) DEFAULT 'UN',
                ncm VARCHAR(20) DEFAULT '00000000',
                hash VARCHAR(64) DEFAULT NULL,
                ativo TINYINT(1) DEFAULT 1,
                atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
                ultima_sincronizacao DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_busca (id_loja, codigo_barras, ativo),
                INDEX idx_interno (id_loja, codigo_interno, ativo),
                INDEX idx_desc (id_loja, descricao, ativo)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS logs_sincronizacao (
                id INT PRIMARY KEY AUTO_INCREMENT,
                id_loja INT NOT NULL DEFAULT 1,
                data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
                status VARCHAR(20) NOT NULL DEFAULT 'SUCESSO',
                produtos_analisados INT DEFAULT 0,
                produtos_atualizados INT DEFAULT 0,
                novos_produtos INT DEFAULT 0,
                tempo_ms INT DEFAULT 0,
                mensagem TEXT DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS configuracao_erp (
                id INT PRIMARY KEY DEFAULT 1,
                nome_loja VARCHAR(100) DEFAULT 'Supermercado Modelo · Loja 01',
                host VARCHAR(100) DEFAULT 'localhost',
                port INT DEFAULT 8745,
                `database` VARCHAR(100) DEFAULT 'vr',
                user VARCHAR(100) DEFAULT 'postgres',
                password VARCHAR(255) DEFAULT '',
                ssl TINYINT(1) DEFAULT 0,
                id_loja INT DEFAULT 1,
                id_situacaocadastro INT DEFAULT 1,
                intervalo_minutos INT DEFAULT 10,
                sincronizacao_automatica TINYINT(1) DEFAULT 1,
                custom_query TEXT DEFAULT NULL,
                atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

            CREATE TABLE IF NOT EXISTS configuracao_mysql (
                id INT PRIMARY KEY DEFAULT 1,
                host VARCHAR(100) DEFAULT 'localhost',
                port INT DEFAULT 3306,
                `database` VARCHAR(100) DEFAULT '',
                user VARCHAR(100) DEFAULT '',
                password VARCHAR(255) DEFAULT '',
                enabled TINYINT(1) DEFAULT 1,
                atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
    } catch (Exception $e) {
        // Prossegue mesmo se tabela já existir
    }
}

if ($pdo) {
    ensureTablesExist($pdo);
}

$action = isset($_GET['action']) ? trim($_GET['action']) : 'status';
// Normaliza ação para remover leading/trailing slashes
$action = trim($action, '/');
$method = $_SERVER['REQUEST_METHOD'];

// Captura payload JSON de requisições POST/PUT
$inputJSON = file_get_contents('php://input');
$inputData = json_decode($inputJSON, true) ?: $_POST;

switch ($action) {

    // --------------------------------------------------------------------------
    // 1. BUSCA DE PRODUTO (POR CÓDIGO DE BARRAS, INTERNO OU DESCRIÇÃO)
    // Ex: api.php?action=search&q=7891000100101&id_loja=1
    // --------------------------------------------------------------------------
    case 'search':
    case 'products/search':
        $q = isset($_GET['q']) ? trim($_GET['q']) : '';
        $id_loja = isset($_GET['id_loja']) ? (int)$_GET['id_loja'] : 1;

        if (empty($q)) {
            sendJson(['error' => 'Código ou termo de busca não informado.'], 400);
        }

        // Prioridade 1: Código de Barras Exato
        $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id_loja = :id_loja AND codigo_barras = :q AND ativo = 1 LIMIT 1");
        $stmt->execute([':id_loja' => $id_loja, ':q' => $q]);
        $prod = $stmt->fetch();

        // Prioridade 2: Código Interno Exato
        if (!$prod) {
            $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id_loja = :id_loja AND codigo_interno = :q AND ativo = 1 LIMIT 1");
            $stmt->execute([':id_loja' => $id_loja, ':q' => $q]);
            $prod = $stmt->fetch();
        }

        // Prioridade 3: Descrição Parcial
        if (!$prod) {
            $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id_loja = :id_loja AND descricao LIKE :term AND ativo = 1 LIMIT 1");
            $stmt->execute([':id_loja' => $id_loja, ':term' => '%' . $q . '%']);
            $prod = $stmt->fetch();
        }

        if ($prod) {
            $prod['preco'] = (float)$prod['preco'];
            $prod['preco_venda'] = $prod['preco_venda'] !== null ? (float)$prod['preco_venda'] : (float)$prod['preco'];
            $prod['produto'] = $prod['descricao'];
            $prod['ativo'] = (bool)$prod['ativo'];
            sendJson($prod, 200);
        }

        // Verificar se está inativo
        $stmt = $pdo->prepare("SELECT descricao, codigo_interno FROM produtos WHERE id_loja = :id_loja AND (codigo_barras = :q OR codigo_interno = :q) AND ativo = 0 LIMIT 1");
        $stmt->execute([':id_loja' => $id_loja, ':q' => $q]);
        $inactive = $stmt->fetch();

        if ($inactive) {
            sendJson(['error' => 'PRODUTO INATIVO NO CADASTRO', 'descricao' => $inactive['descricao']], 404);
        }

        sendJson(['error' => 'PRODUTO NÃO ENCONTRADO'], 404);
        break;

    // --------------------------------------------------------------------------
    // 2. LISTAR TODOS OS PRODUTOS (PARA CACHE OFFLINE DO TERMINAL)
    // Ex: api.php?action=products&id_loja=1
    // --------------------------------------------------------------------------
    case 'products':
        $id_loja = isset($_GET['id_loja']) ? (int)$_GET['id_loja'] : 1;
        $includeInactives = isset($_GET['include_inactives']) && $_GET['include_inactives'] === 'true';

        $sql = "SELECT * FROM produtos WHERE id_loja = :id_loja";
        if (!$includeInactives) {
            $sql .= " AND ativo = 1";
        }
        $sql .= " ORDER BY descricao ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id_loja' => $id_loja]);
        $rows = $stmt->fetchAll();

        $result = [];
        foreach ($rows as $r) {
            $result[] = [
                'id' => $r['id'],
                'id_loja' => (int)$r['id_loja'],
                'codigo_interno' => $r['codigo_interno'],
                'codigo_barras' => $r['codigo_barras'],
                'descricao' => $r['descricao'],
                'produto' => $r['descricao'],
                'preco' => (float)$r['preco'],
                'preco_venda' => $r['preco_venda'] !== null ? (float)$r['preco_venda'] : (float)$r['preco'],
                'embalagem' => $r['embalagem'],
                'ncm' => $r['ncm'],
                'hash' => $r['hash'],
                'ativo' => (bool)$r['ativo'],
                'atualizado_em' => $r['atualizado_em'],
                'ultima_sincronizacao' => $r['ultima_sincronizacao']
            ];
        }

        sendJson($result, 200);
        break;

    // --------------------------------------------------------------------------
    // 3. STATUS DO SERVIDOR E CONTAGEM
    // Ex: api.php?action=status&id_loja=1
    // --------------------------------------------------------------------------
    case 'status':
        $id_loja = isset($_GET['id_loja']) ? (int)$_GET['id_loja'] : 1;

        $stmt = $pdo->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN ativo = 1 THEN 1 ELSE 0 END) as ativos, SUM(CASE WHEN ativo = 0 THEN 1 ELSE 0 END) as inativos, MAX(atualizado_em) as ultima_atualizacao FROM produtos WHERE id_loja = :id_loja");
        $stmt->execute([':id_loja' => $id_loja]);
        $counts = $stmt->fetch();

        $stmtStore = $pdo->prepare("SELECT nome FROM lojas WHERE id = :id_loja LIMIT 1");
        $stmtStore->execute([':id_loja' => $id_loja]);
        $store = $stmtStore->fetch();

        sendJson([
            'success' => true,
            'banco_online' => true,
            'servidor' => 'Hostinger MySQL PHP API',
            'loja_atual' => $id_loja,
            'nome_loja' => $store ? $store['nome'] : 'Loja ' . $id_loja,
            'total_produtos' => (int)($counts['total'] ?? 0),
            'total_produtos_ativos' => (int)($counts['ativos'] ?? 0),
            'total_produtos_inativos' => (int)($counts['inativos'] ?? 0),
            'ultima_sincronizacao' => $counts['ultima_atualizacao'] ?? date('Y-m-d H:i:s'),
            'hora_servidor' => date('d/m/Y H:i:s')
        ], 200);
        break;

    // --------------------------------------------------------------------------
    // 4. ATUALIZAR / SINCRONIZAR PRODUTOS EM LOTE (RECEBE DO ERP / AGENTE)
    // POST api.php?action=sync
    // --------------------------------------------------------------------------
    case 'sync':
    case 'sync-batch':
    case 'products/sync-batch':
        if ($method !== 'POST') {
            sendJson(['error' => 'Método não permitido. Use POST.'], 405);
        }

        $items = $inputData['items'] ?? [];
        $id_loja = isset($inputData['id_loja']) ? (int)$inputData['id_loja'] : 1;
        $is_full_sync = !empty($inputData['is_full_sync']);

        if (!is_array($items) || empty($items)) {
            sendJson(['error' => 'Array de produtos "items" vazio ou inválido.'], 400);
        }

        $now = date('Y-m-d H:i:s');
        $startTime = microtime(true);

        $pdo->beginTransaction();

        $query = "INSERT INTO produtos (
            id, id_loja, codigo_interno, codigo_barras, descricao,
            preco, preco_venda, embalagem, ncm, hash, ativo, atualizado_em, ultima_sincronizacao
        ) VALUES (
            :id, :id_loja, :codigo_interno, :codigo_barras, :descricao,
            :preco, :preco_venda, :embalagem, :ncm, :hash, :ativo, :atualizado_em, :ultima_sincronizacao
        ) ON DUPLICATE KEY UPDATE
            descricao = VALUES(descricao),
            preco = VALUES(preco),
            preco_venda = VALUES(preco_venda),
            embalagem = VALUES(embalagem),
            ncm = VALUES(ncm),
            hash = VALUES(hash),
            ativo = 1,
            atualizado_em = VALUES(atualizado_em),
            ultima_sincronizacao = VALUES(ultima_sincronizacao)";

        $stmt = $pdo->prepare($query);

        $totalProcessados = 0;
        $incomingCodes = [];

        foreach ($items as $item) {
            $intCode = trim($item['codigo_interno'] ?? $item['id_produto'] ?? '');
            $barcode = trim($item['codigo_barras'] ?? $item['codigobarras'] ?? $item['ean'] ?? '');
            $desc = mb_strtoupper(trim($item['produto'] ?? $item['descricao'] ?? $item['descricaocompleta'] ?? ''));
            $preco = (float)str_replace(',', '.', $item['preco_venda'] ?? $item['preco'] ?? $item['precovenda'] ?? 0);
            $emb = mb_strtoupper(trim($item['embalagem'] ?? $item['tipoembalagem_desc'] ?? 'UN'));
            $ncm = trim($item['ncm'] ?? '00000000');

            if (empty($desc) || (empty($intCode) && empty($barcode))) {
                continue;
            }

            $primaryCode = !empty($intCode) ? $intCode : $barcode;
            $barCodeFinal = !empty($barcode) ? $barcode : $primaryCode;
            $id = $id_loja . '_' . $primaryCode . '_' . $barCodeFinal;

            $hashContent = "{$primaryCode}|{$barCodeFinal}|{$desc}|" . number_format($preco, 2, '.', '') . "|{$emb}|{$id_loja}";
            $hash = hash('sha256', $hashContent);

            $stmt->execute([
                ':id' => $id,
                ':id_loja' => $id_loja,
                ':codigo_interno' => $primaryCode,
                ':codigo_barras' => $barCodeFinal,
                ':descricao' => $desc,
                ':preco' => $preco,
                ':preco_venda' => $preco,
                ':embalagem' => $emb ?: 'UN',
                ':ncm' => $ncm ?: '00000000',
                ':hash' => $hash,
                ':ativo' => 1,
                ':atualizado_em' => $now,
                ':ultima_sincronizacao' => $now
            ]);

            $totalProcessados++;
            $incomingCodes[] = $pdo->quote($barCodeFinal);
        }

        // Se for sincronização completa do ERP, inativa os produtos que não vieram
        $desativados = 0;
        if ($is_full_sync && !empty($incomingCodes)) {
            $inList = implode(',', array_slice($incomingCodes, 0, 5000));
            $sqlDeactivate = "UPDATE produtos SET ativo = 0, atualizado_em = '{$now}' WHERE id_loja = {$id_loja} AND codigo_barras NOT IN ({$inList})";
            $desativados = $pdo->exec($sqlDeactivate);
        }

        $tempoMs = (int)((microtime(true) - $startTime) * 1000);

        // Gravar Log de Sincronização
        $stmtLog = $pdo->prepare("INSERT INTO logs_sincronizacao (id_loja, data_hora, status, produtos_analisados, produtos_atualizados, novos_produtos, tempo_ms, mensagem) VALUES (:id_loja, :data_hora, 'SUCESSO', :total, :total, 0, :tempo, :msg)");
        $stmtLog->execute([
            ':id_loja' => $id_loja,
            ':data_hora' => $now,
            ':total' => $totalProcessados,
            ':tempo' => $tempoMs,
            ':msg' => "Sincronização em nuvem: {$totalProcessados} produtos processados ({$tempoMs}ms)."
        ]);

        $pdo->commit();

        sendJson([
            'success' => true,
            'message' => "{$totalProcessados} produtos sincronizados com sucesso na Hostinger!",
            'total_processados' => $totalProcessados,
            'total_gravados' => $totalProcessados,
            'desativados' => $desativados,
            'tempo_ms' => $tempoMs,
            'data_hora' => $now
        ], 200);
        break;

    // --------------------------------------------------------------------------
    // 5. CONFIGURAÇÃO ERP (GET & POST) - PERSISTÊNCIA EM BANCO
    // GET/POST api.php?action=erp/config ou action=erp-config
    // --------------------------------------------------------------------------
    case 'erp/config':
    case 'erp-config':
    case 'config':
        if ($method === 'POST') {
            $nome_loja = trim($inputData['nome_loja'] ?? '');
            $host = trim($inputData['host'] ?? 'localhost');
            $port = (int)($inputData['port'] ?? 8745);
            $database = trim($inputData['database'] ?? 'vr');
            $user = trim($inputData['user'] ?? 'postgres');
            $password = $inputData['password'] ?? '';
            $ssl = !empty($inputData['ssl']) ? 1 : 0;
            $id_loja = (int)($inputData['id_loja'] ?? 1);
            $id_situacaocadastro = (int)($inputData['id_situacaocadastro'] ?? 1);
            $intervalo_minutos = (int)($inputData['intervalo_minutos'] ?? 10);
            $sincronizacao_automatica = isset($inputData['sincronizacao_automatica']) ? ($inputData['sincronizacao_automatica'] ? 1 : 0) : 1;
            $custom_query = $inputData['custom_query'] ?? null;

            // Busca senha atual se vier máscara
            if ($password === '••••••••' || $password === '') {
                $stmtCheck = $pdo->prepare("SELECT password FROM configuracao_erp WHERE id = 1 LIMIT 1");
                $stmtCheck->execute();
                $row = $stmtCheck->fetch();
                if ($row && !empty($row['password'])) {
                    $password = $row['password'];
                }
            }

            $stmt = $pdo->prepare("
                INSERT INTO configuracao_erp (id, nome_loja, host, port, `database`, user, password, ssl, id_loja, id_situacaocadastro, intervalo_minutos, sincronizacao_automatica, custom_query)
                VALUES (1, :nome_loja, :host, :port, :database, :user, :password, :ssl, :id_loja, :id_situacaocadastro, :intervalo_minutos, :sincronizacao_automatica, :custom_query)
                ON DUPLICATE KEY UPDATE
                    nome_loja = VALUES(nome_loja),
                    host = VALUES(host),
                    port = VALUES(port),
                    `database` = VALUES(`database`),
                    user = VALUES(user),
                    password = VALUES(password),
                    ssl = VALUES(ssl),
                    id_loja = VALUES(id_loja),
                    id_situacaocadastro = VALUES(id_situacaocadastro),
                    intervalo_minutos = VALUES(intervalo_minutos),
                    sincronizacao_automatica = VALUES(sincronizacao_automatica),
                    custom_query = VALUES(custom_query)
            ");
            $stmt->execute([
                ':nome_loja' => $nome_loja ?: 'Supermercado Modelo · Loja 01',
                ':host' => $host,
                ':port' => $port,
                ':database' => $database,
                ':user' => $user,
                ':password' => $password,
                ':ssl' => $ssl,
                ':id_loja' => $id_loja,
                ':id_situacaocadastro' => $id_situacaocadastro,
                ':intervalo_minutos' => $intervalo_minutos,
                ':sincronizacao_automatica' => $sincronizacao_automatica,
                ':custom_query' => $custom_query,
            ]);

            // Atualiza nome na tabela de lojas se fornecido
            if (!empty($nome_loja)) {
                $stmtLoja = $pdo->prepare("UPDATE lojas SET nome = :nome WHERE id = :id_loja");
                $stmtLoja->execute([':nome' => $nome_loja, ':id_loja' => $id_loja]);
            }

            sendJson([
                'success' => true,
                'message' => 'Configurações do ERP salvas com sucesso no banco de dados!',
            ], 200);
        } else {
            // GET
            $stmt = $pdo->prepare("SELECT * FROM configuracao_erp WHERE id = 1 LIMIT 1");
            $stmt->execute();
            $cfg = $stmt->fetch();

            if (!$cfg) {
                $cfg = [
                    'id' => 1,
                    'nome_loja' => 'Supermercado Modelo · Loja 01',
                    'host' => 'localhost',
                    'port' => 8745,
                    'database' => 'vr',
                    'user' => 'postgres',
                    'password' => '',
                    'ssl' => false,
                    'id_loja' => 1,
                    'id_situacaocadastro' => 1,
                    'intervalo_minutos' => 10,
                    'sincronizacao_automatica' => true,
                    'custom_query' => null,
                ];
            } else {
                $cfg['port'] = (int)$cfg['port'];
                $cfg['id_loja'] = (int)$cfg['id_loja'];
                $cfg['id_situacaocadastro'] = (int)$cfg['id_situacaocadastro'];
                $cfg['intervalo_minutos'] = (int)$cfg['intervalo_minutos'];
                $cfg['ssl'] = (bool)$cfg['ssl'];
                $cfg['sincronizacao_automatica'] = (bool)$cfg['sincronizacao_automatica'];
                $cfg['password'] = !empty($cfg['password']) ? '••••••••' : '';
            }

            sendJson($cfg, 200);
        }
        break;

    // --------------------------------------------------------------------------
    // 6. CONFIGURAÇÃO MYSQL (GET & POST)
    // --------------------------------------------------------------------------
    case 'mysql/config':
    case 'mysql-config':
        if ($method === 'POST') {
            $host = trim($inputData['host'] ?? 'localhost');
            $port = (int)($inputData['port'] ?? 3306);
            $database = trim($inputData['database'] ?? '');
            $user = trim($inputData['user'] ?? '');
            $password = $inputData['password'] ?? '';
            $enabled = isset($inputData['enabled']) ? ($inputData['enabled'] ? 1 : 0) : 1;

            // Salva credenciais no arquivo JSON
            saveDbCredentials($host, $port, $database, $user, $password);

            // Testa conexão com as novas credenciais
            $testCreds = [
                'host' => $host,
                'port' => $port,
                'database' => $database,
                'user' => $user,
                'password' => $password
            ];

            $testPdo = null;
            $connectionStatus = 'PENDENTE';
            $connectionMessage = '';

            try {
                $testPdo = getDbConnection($testCreds, false);
                if ($testPdo) {
                    ensureTablesExist($testPdo);
                    $connectionStatus = 'CONECTADO';
                    $connectionMessage = 'Conexão ativa com o banco MySQL Hostinger!';

                    // Salva também na tabela configuracao_mysql
                    $stmt = $testPdo->prepare("
                        INSERT INTO configuracao_mysql (id, host, port, `database`, user, password, enabled)
                        VALUES (1, :host, :port, :database, :user, :password, :enabled)
                        ON DUPLICATE KEY UPDATE
                            host = VALUES(host),
                            port = VALUES(port),
                            `database` = VALUES(`database`),
                            user = VALUES(user),
                            password = VALUES(password),
                            enabled = VALUES(enabled)
                    ");
                    $stmt->execute([
                        ':host' => $host,
                        ':port' => $port,
                        ':database' => $database,
                        ':user' => $user,
                        ':password' => $password,
                        ':enabled' => $enabled,
                    ]);
                }
            } catch (Exception $e) {
                $connectionStatus = 'ERRO';
                $connectionMessage = 'Configuração salva no arquivo, mas o MySQL retornou: ' . $e->getMessage();
            }

            sendJson([
                'success' => true,
                'message' => 'Configuração salva com sucesso!',
                'status' => $connectionStatus,
                'status_mensagem' => $connectionMessage,
                'config' => [
                    'host' => $host,
                    'port' => $port,
                    'database' => $database,
                    'user' => $user,
                    'has_password' => !empty($password),
                    'enabled' => (bool)$enabled
                ]
            ], 200);
        } else {
            $mcfg = [
                'host' => DB_HOST,
                'port' => DB_PORT,
                'database' => DB_NAME,
                'user' => DB_USER,
                'has_password' => !empty(DB_PASS),
                'enabled' => true,
            ];

            if ($pdo) {
                try {
                    $stmt = $pdo->prepare("SELECT * FROM configuracao_mysql WHERE id = 1 LIMIT 1");
                    $stmt->execute();
                    $dbCfg = $stmt->fetch();
                    if ($dbCfg) {
                        $mcfg['host'] = $dbCfg['host'];
                        $mcfg['port'] = (int)$dbCfg['port'];
                        $mcfg['database'] = $dbCfg['database'];
                        $mcfg['user'] = $dbCfg['user'];
                        $mcfg['has_password'] = !empty($dbCfg['password']) || !empty(DB_PASS);
                        $mcfg['enabled'] = (bool)$dbCfg['enabled'];
                    }
                } catch (Exception $e) {}
            }

            sendJson($mcfg, 200);
        }
        break;

    // --------------------------------------------------------------------------
    // 7. TESTE DE CONEXÃO MYSQL
    // --------------------------------------------------------------------------
    case 'test':
    case 'mysql/test-connection':
        $testCreds = null;
        if ($method === 'POST' && !empty($inputData['database'])) {
            $testCreds = [
                'host' => trim($inputData['host'] ?? 'localhost'),
                'port' => (int)($inputData['port'] ?? 3306),
                'database' => trim($inputData['database'] ?? ''),
                'user' => trim($inputData['user'] ?? ''),
                'password' => $inputData['password'] ?? DB_PASS
            ];
        }

        try {
            $conn = $testCreds ? getDbConnection($testCreds, false) : ($pdo ?: getDbConnection(null, false));
            $ver = $conn->query('SELECT VERSION() as version, NOW() as server_time')->fetch();
            ensureTablesExist($conn);
            sendJson([
                'success' => true,
                'message' => 'Conexão com MySQL Hostinger ativa e funcionando!',
                'info' => $ver
            ], 200);
        } catch (Exception $e) {
            sendJson([
                'success' => false,
                'message' => 'Falha na conexão com o MySQL Hostinger: ' . $e->getMessage()
            ], 200);
        }
        break;

    // --------------------------------------------------------------------------
    // 8. LOGS DE SINCRONIZAÇÃO
    // --------------------------------------------------------------------------
    case 'logs':
    case 'sync/logs':
        $id_loja = isset($_GET['id_loja']) ? (int)$_GET['id_loja'] : 1;
        $stmt = $pdo->prepare("SELECT * FROM logs_sincronizacao WHERE id_loja = :id_loja ORDER BY data_hora DESC LIMIT 50");
        $stmt->execute([':id_loja' => $id_loja]);
        $logs = $stmt->fetchAll();
        sendJson($logs, 200);
        break;

    // --------------------------------------------------------------------------
    // 9. CARGA INSTANTÂNEA DE CATÁLOGO NO MYSQL
    // Ex: api.php?action=instant-load
    // --------------------------------------------------------------------------
    case 'instant-load':
    case 'sync/instant-load':
    case 'carga-inicial':
        $catalogoPadrao = [
            ['cod' => '1001', 'ean' => '7891000100101', 'desc' => 'LEITE INTEGRAL PIRACANJUBA 1L', 'preco' => 5.49, 'emb' => 'UN', 'ncm' => '04012010'],
            ['cod' => '1002', 'ean' => '7891000200202', 'desc' => 'ARROZ BRANCO TIPO 1 CAMIL 5KG', 'preco' => 28.90, 'emb' => 'PC', 'ncm' => '10063021'],
            ['cod' => '1003', 'ean' => '7891000300303', 'desc' => 'FEIJAO CARIOCA CAMIL 1KG', 'preco' => 7.89, 'emb' => 'UN', 'ncm' => '07133399'],
            ['cod' => '1004', 'ean' => '7891000400404', 'desc' => 'OLEO DE SOJA LIZA PET 900ML', 'preco' => 6.49, 'emb' => 'UN', 'ncm' => '15079011'],
            ['cod' => '1005', 'ean' => '7891000500505', 'desc' => 'CAFE TORRADO E MOIDO PILAO 500G', 'preco' => 18.90, 'emb' => 'UN', 'ncm' => '09012100'],
            ['cod' => '1006', 'ean' => '7891000600606', 'desc' => 'ACUCAR REFINADO UNIAO 1KG', 'preco' => 4.69, 'emb' => 'UN', 'ncm' => '17019900'],
            ['cod' => '1007', 'ean' => '7891000700707', 'desc' => 'MACARRAO ESPAGUETE RENATA 500G', 'preco' => 3.99, 'emb' => 'UN', 'ncm' => '19021900'],
            ['cod' => '1008', 'ean' => '7891000800808', 'desc' => 'MOLHO DE TOMATE ELEFANTE SACHE 300G', 'preco' => 2.49, 'emb' => 'UN', 'ncm' => '21032010'],
            ['cod' => '1009', 'ean' => '7891000900909', 'desc' => 'DETERGENTE LIQUIDO YPE NEUTRO 500ML', 'preco' => 2.29, 'emb' => 'UN', 'ncm' => '34022000'],
            ['cod' => '1010', 'ean' => '7891000110100', 'desc' => 'SABAO EM PO OMO LAVAGEM PERFEITA 800G', 'preco' => 14.90, 'emb' => 'CX', 'ncm' => '34029039'],
            ['cod' => '1011', 'ean' => '7891000120123', 'desc' => 'AMACIANTE DE ROUPAS DOWNY BRISA 500ML', 'preco' => 12.99, 'emb' => 'UN', 'ncm' => '38099190'],
            ['cod' => '1012', 'ean' => '7891000130134', 'desc' => 'PAPEL HIGIENICO NEVE FOLHA DUPLA C/12', 'preco' => 21.90, 'emb' => 'PC', 'ncm' => '48181000'],
            ['cod' => '1013', 'ean' => '7891000140145', 'desc' => 'CREME DENTAL COLGATE TOTAL 12 90G', 'preco' => 6.99, 'emb' => 'UN', 'ncm' => '33061000'],
            ['cod' => '1014', 'ean' => '7891000150156', 'desc' => 'SABONETE DOVE ORIGINAL 90G', 'preco' => 4.29, 'emb' => 'UN', 'ncm' => '34011190'],
            ['cod' => '1015', 'ean' => '7891000160167', 'desc' => 'REFRIGERANTE COCA-COLA PET 2L', 'preco' => 9.99, 'emb' => 'UN', 'ncm' => '22021000'],
        ];

        $now = date('Y-m-d H:i:s');
        $id_loja = isset($_GET['id_loja']) ? (int)$_GET['id_loja'] : 1;

        $stmt = $pdo->prepare("
            INSERT INTO produtos (id, id_loja, codigo_interno, codigo_barras, descricao, preco, preco_venda, embalagem, ncm, hash, ativo, atualizado_em, ultima_sincronizacao)
            VALUES (:id, :id_loja, :codigo_interno, :codigo_barras, :descricao, :preco, :preco_venda, :embalagem, :ncm, :hash, 1, :atualizado_em, :ultima_sincronizacao)
            ON DUPLICATE KEY UPDATE descricao = VALUES(descricao), preco = VALUES(preco), preco_venda = VALUES(preco_venda), ativo = 1, atualizado_em = VALUES(atualizado_em)
        ");

        $inserted = 0;
        foreach ($catalogoPadrao as $item) {
            $id = $id_loja . '_' . $item['cod'] . '_' . $item['ean'];
            $hash = hash('sha256', "{$item['cod']}|{$item['ean']}|{$item['desc']}|{$item['preco']}|{$item['emb']}|{$id_loja}");
            $stmt->execute([
                ':id' => $id,
                ':id_loja' => $id_loja,
                ':codigo_interno' => $item['cod'],
                ':codigo_barras' => $item['ean'],
                ':descricao' => $item['desc'],
                ':preco' => $item['preco'],
                ':preco_venda' => $item['preco'],
                ':embalagem' => $item['emb'],
                ':ncm' => $item['ncm'],
                ':hash' => $hash,
                ':atualizado_em' => $now,
                ':ultima_sincronizacao' => $now
            ]);
            $inserted++;
        }

        sendJson([
            'success' => true,
            'message' => "Carga instantânea gravada com sucesso no MySQL! {$inserted} produtos inseridos.",
            'total_produtos' => $inserted
        ], 200);
        break;

    case 'agent-heartbeat':
        sendJson(['success' => true, 'timestamp' => date('Y-m-d H:i:s')], 200);
        break;

    // --------------------------------------------------------------------------
    // 15. DOWNLOADS DE SCRIPTS BAT, PS1, CSV E PACOTES ZIP
    // --------------------------------------------------------------------------
    case 'deploy/download-sync-bat':
    case 'download-sync-bat':
    case 'download-bat':
        $batPath = __DIR__ . '/sincronizar_automatico_10min.bat';
        header('Content-Type: application/x-bat; charset=utf-8');
        header('Content-Disposition: attachment; filename="sincronizar_automatico_10min.bat"');
        if (file_exists($batPath)) {
            readfile($batPath);
        } else {
            echo "@echo off\r\nchcp 65001 > nul\r\ntitle Central Busca Preco - Sincronizador Automatico (10 Minutos)\r\ncolor 0A\r\ncls\r\n\r\nset SUBDOMINIO=buscapreco.instara.com.br\r\nset ID_LOJA=1\r\n\r\n:LOOP\r\necho [%date% %time%] Disparando carga para https://%SUBDOMINIO%...\r\ncurl -s -k -X GET \"https://%SUBDOMINIO%/api.php?action=instant-load&id_loja=%ID_LOJA%\"\r\necho.\r\necho Proxima carga em 10 minutos (600s)...\r\ntimeout /t 600 /nobreak\r\ngoto LOOP\r\n";
        }
        exit;

    case 'deploy/download-agendador-bat':
    case 'download-agendador-bat':
        $batPath = __DIR__ . '/instalar_agendador_10min.bat';
        header('Content-Type: application/x-bat; charset=utf-8');
        header('Content-Disposition: attachment; filename="instalar_agendador_10min.bat"');
        if (file_exists($batPath)) {
            readfile($batPath);
        } else {
            echo "@echo off\r\nchcp 65001 > nul\r\nschtasks /create /tn \"BuscaPreco_Carga_10Min\" /tr \"\\\"%~dp0sincronizar_automatico_10min.bat\\\"\" /sc minute /mo 10 /f\r\npause\r\n";
        }
        exit;

    case 'deploy/download-exemplo-csv':
    case 'download-exemplo-csv':
        $csvPath = __DIR__ . '/produtos_exemplo.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="produtos_exemplo.csv"');
        if (file_exists($csvPath)) {
            readfile($csvPath);
        } else {
            echo "codigo_interno,codigo_barras,descricao,preco,embalagem,ncm\r\n101,7891000100103,ARROZ TIPO 1 5KG,29.90,UN,10063021\r\n102,7891000200202,FEIJAO CARIOCA 1KG,8.49,UN,07133399\r\n103,7891000300301,OLEO DE SOJA 900ML,6.79,UN,15079011\r\n";
        }
        exit;

    case 'deploy/download-sync-kit-zip':
    case 'download-sync-kit-zip':
        $zipPath = __DIR__ . '/kit_sincronizador_automatico_10min.zip';
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="kit_sincronizador_automatico_10min.zip"');
        if (file_exists($zipPath)) {
            readfile($zipPath);
            exit;
        }
        // Se a classe ZipArchive existir no PHP do servidor, cria em tempo de execução
        if (class_exists('ZipArchive')) {
            $tmpFile = tempnam(sys_get_temp_dir(), 'zip');
            $zip = new ZipArchive();
            if ($zip->open($tmpFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
                if (file_exists(__DIR__ . '/sincronizar_automatico_10min.bat')) {
                    $zip->addFile(__DIR__ . '/sincronizar_automatico_10min.bat', 'sincronizar_automatico_10min.bat');
                }
                if (file_exists(__DIR__ . '/sincronizar_nuvem.ps1')) {
                    $zip->addFile(__DIR__ . '/sincronizar_nuvem.ps1', 'sincronizar_nuvem.ps1');
                }
                if (file_exists(__DIR__ . '/instalar_agendador_10min.bat')) {
                    $zip->addFile(__DIR__ . '/instalar_agendador_10min.bat', 'instalar_agendador_10min.bat');
                }
                $zip->addFromString('LEIA-ME.txt', "KIT DE SINCRONIZACAO 10 MINUTOS\r\n1. De dois cliques em sincronizar_automatico_10min.bat para rodar continuous.\r\n2. Ou execute instalar_agendador_10min.bat como Administrador.");
                $zip->close();
                readfile($tmpFile);
                @unlink($tmpFile);
                exit;
            }
        }
        sendJson(['error' => 'Arquivo ZIP nao encontrado no servidor.'], 404);
        exit;

    case 'deploy/download-instalacao-zip':
    case 'download-instalacao-zip':
    case 'download-hostinger-zip':
        $zipPath = __DIR__ . '/buscapreco_instalacao_completa.zip';
        if (file_exists($zipPath)) {
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="buscapreco_instalacao_completa.zip"');
            readfile($zipPath);
            exit;
        }
        sendJson(['error' => 'Pacote de instalacao nao encontrado.'], 404);
        exit;

    case 'deploy/download-atualizacao-zip':
    case 'download-atualizacao-zip':
        $zipPath = __DIR__ . '/buscapreco_pacote_atualizacao.zip';
        if (file_exists($zipPath)) {
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="buscapreco_pacote_atualizacao.zip"');
            readfile($zipPath);
            exit;
        }
        sendJson(['error' => 'Pacote de atualizacao nao encontrado.'], 404);
        exit;

    default:
        sendJson(['error' => 'Ação desconhecida: ' . htmlspecialchars($action)], 404);
        break;
}
